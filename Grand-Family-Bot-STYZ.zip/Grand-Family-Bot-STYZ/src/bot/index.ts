import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  ModalBuilder,
  OverwriteType,
  PermissionFlagsBits,
  REST,
  Routes,
  TextInputBuilder,
  TextInputStyle,
  type ButtonInteraction,
  type ChatInputCommandInteraction,
  type Guild,
  type GuildMember,
  type Interaction,
  type Role,
  type TextChannel,
} from "discord.js";
import { logger } from "../lib/logger";
import {
  BotDatabase,
  type Application,
  type Family,
  type Settings,
} from "./database";

const HEX_PATTERN = /^#[0-9a-f]{6}$/i;
const DISCORD_ID_PATTERN = /^\d{16,22}$/;
const SETUP_TTL_MS = 10 * 60 * 1000;

type SetupDraft = Omit<Settings, "panelMessageId">;
type SetupStageOneDraft = Omit<SetupDraft, "deputyLeaderRoleId" | "seniorRoleId" | "familyRoleId">;

const setupDrafts = new Map<string, { expiresAt: number; draft: SetupStageOneDraft }>();

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : "Неизвестная ошибка Discord API.";
}

function cleanId(value: string): string {
  return value.trim().replace(/^<@!?(\d+)>$/, "$1");
}

function setupKey(guildId: string, userId: string): string {
  return `${guildId}:${userId}`;
}

function roleIsUsable(role: Role, botMember: GuildMember): boolean {
  return !role.managed && role.position < botMember.roles.highest.position;
}

function isCurator(member: GuildMember, settings: Settings): boolean {
  return (
    member.roles.cache.has(settings.mainCuratorRoleId) ||
    member.roles.cache.has(settings.deputyCuratorRoleId)
  );
}

function rankRoleIds(family: Family, settings: Settings): string[] {
  const roleIds = [family.familyRoleId];
  if (family.rank >= 8) roleIds.push(settings.seniorRoleId);
  if (family.rank >= 9) roleIds.push(settings.deputyLeaderRoleId);
  if (family.rank >= 10) roleIds.push(family.ldRoleId);
  return roleIds;
}

function relevantRankRoleIds(family: Family, settings: Settings): string[] {
  return [
    family.familyRoleId,
    family.ldRoleId,
    settings.seniorRoleId,
    settings.deputyLeaderRoleId,
    settings.leaderRoleId,
  ];
}

async function fetchBotMember(guild: Guild): Promise<GuildMember> {
  const me = guild.members.me ?? (await guild.members.fetchMe());
  if (!me) throw new Error("Не удалось определить участника-бота на сервере.");
  return me;
}

async function validateSetupIds(guild: Guild, draft: SetupDraft): Promise<void> {
  const panel = await guild.channels.fetch(draft.panelChannelId);
  const applications = await guild.channels.fetch(draft.applicationsChannelId);
  if (!panel || !applications) throw new Error("Канал панели или канал заявлений не найден.");
  if (!panel.isTextBased() || !("send" in panel)) {
    throw new Error("Канал панели должен быть текстовым каналом, доступным боту.");
  }
  if (!applications.isTextBased() || !("send" in applications)) {
    throw new Error("Канал заявлений должен быть текстовым каналом, доступным боту.");
  }

  const bot = await fetchBotMember(guild);
  const roleIds = [
    draft.mainCuratorRoleId,
    draft.deputyCuratorRoleId,
    draft.leaderRoleId,
    draft.deputyLeaderRoleId,
    draft.seniorRoleId,
    draft.familyRoleId,
  ];
  for (const roleId of roleIds) {
    const role = await guild.roles.fetch(roleId);
    if (!role) throw new Error(`Роль с ID ${roleId} не найдена.`);
    if (!roleIsUsable(role, bot)) {
      throw new Error(`Бот не может видеть или использовать роль «${role.name}». Поднимите роль бота выше.`);
    }
  }
}

function setupStageOneModal(): ModalBuilder {
  const fields = [
    ["panel_channel_id", "ID канала панели"],
    ["applications_channel_id", "ID канала заявлений"],
    ["main_curator_role_id", "ID роли главного куратора"],
    ["deputy_curator_role_id", "ID роли заместителя куратора"],
    ["leader_role_id", "ID роли лидера"],
  ] as const;
  const modal = new ModalBuilder()
    .setCustomId("setup:stage1")
    .setTitle("Grand Family Bot · этап 1");
  modal.addComponents(
    ...fields.map(([id, label]) =>
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId(id)
          .setLabel(label)
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(22),
      ),
    ),
  );
  return modal;
}

function setupStageTwoModal(): ModalBuilder {
  const fields = [
    ["deputy_leader_role_id", "ID роли заместителя"],
    ["senior_role_id", "ID роли старшего состава"],
    ["family_role_id", "ID базовой роли семьи"],
  ] as const;
  const modal = new ModalBuilder()
    .setCustomId("setup:stage2")
    .setTitle("Grand Family Bot · этап 2");
  modal.addComponents(
    ...fields.map(([id, label]) =>
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId(id)
          .setLabel(label)
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(22),
      ),
    ),
  );
  return modal;
}

function setupContinueComponents(): ActionRowBuilder<ButtonBuilder>[] {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("setup:continue")
        .setLabel("Перейти к этапу 2")
        .setStyle(ButtonStyle.Primary),
    ),
  ];
}

function applicationModal(): ModalBuilder {
  const fields = [
    ["nickname", "Ваш никнейм", "Например: Alexander"],
    ["family_name", "Название семьи", "Например: Black Family"],
    ["color_hex", "HEX-цвет", "Например: #8B5CF6"],
    ["rank", "Ранг от 1 до 10", "Только число"],
  ] as const;
  const modal = new ModalBuilder().setCustomId("application:create").setTitle("Заявление в семью");
  modal.addComponents(
    ...fields.map(([id, label, placeholder]) =>
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId(id)
          .setLabel(label)
          .setPlaceholder(placeholder)
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(id === "family_name" ? 80 : 32),
      ),
    ),
  );
  return modal;
}

function transferModal(): ModalBuilder {
  return new ModalBuilder()
    .setCustomId("family:transfer")
    .setTitle("Передача семьи")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("target_user_id")
          .setLabel("Discord ID или mention нового владельца")
          .setPlaceholder("123456789012345678 или @участник")
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(32),
      ),
    );
}

function deleteModal(): ModalBuilder {
  return new ModalBuilder()
    .setCustomId("family:delete")
    .setTitle("Удаление семьи")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("reason")
          .setLabel("Причина удаления")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMinLength(3)
          .setMaxLength(500),
      ),
    );
}

function rejectModal(kind: "application" | "transfer", id: number): ModalBuilder {
  return new ModalBuilder()
    .setCustomId(`review:reject:${kind}:${id}`)
    .setTitle("Причина отказа")
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId("reason")
          .setLabel("Укажите причину")
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMinLength(3)
          .setMaxLength(500),
      ),
    );
}

function panelComponents(): ActionRowBuilder<ButtonBuilder>[] {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("panel:apply")
        .setLabel("Подать заявление")
        .setEmoji("📋")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("panel:delete")
        .setLabel("Удалить семью")
        .setEmoji("🗑️")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("panel:transfer")
        .setLabel("Передать семью")
        .setEmoji("🔄")
        .setStyle(ButtonStyle.Secondary),
    ),
  ];
}

function reviewComponents(kind: "application" | "transfer", id: number): ActionRowBuilder<ButtonBuilder>[] {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId(`review:approve:${kind}:${id}`)
        .setLabel("Одобрить")
        .setEmoji("✅")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`review:reject:${kind}:${id}`)
        .setLabel("Отказать")
        .setEmoji("❌")
        .setStyle(ButtonStyle.Danger),
    ),
  ];
}

function disabledComponents(): ActionRowBuilder<ButtonBuilder>[] {
  return [
    new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId("disabled:approve").setLabel("Рассмотрено").setStyle(ButtonStyle.Secondary).setDisabled(true),
    ),
  ];
}

function makePanelEmbed(): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0x8b5cf6)
    .setTitle("Grand Family Bot")
    .setDescription(
      "Создайте свою семью, соберите команду и управляйте пространством.\n\n" +
        "Выберите действие ниже. Заявление будет рассмотрено кураторами.",
    )
    .addFields(
      { name: "Заявление", value: "Заполните форму и отправьте ровно 3 изображения-доказательства.", inline: false },
      { name: "Передача", value: "Передайте семью участнику по Discord ID или mention.", inline: true },
      { name: "Удаление", value: "Удаление выполняется только после одобрения куратора.", inline: true },
    )
    .setFooter({ text: "Grand Family Bot · честная модерация семей" })
    .setTimestamp();
}

async function ensureFamilyRole(
  guild: Guild,
  name: string,
  colorHex: string,
  minimumPosition: number,
  botMember: GuildMember,
): Promise<Role> {
  const existing = guild.roles.cache.find((role) => role.name === name && !role.managed);
  const role =
    existing ??
    (await guild.roles.create({
      name,
      color: colorHex as `#${string}`,
      reason: "Grand Family Bot: создание семейной роли",
    }));
  if (!roleIsUsable(role, botMember)) {
    throw new Error(`Бот не может управлять ролью «${name}». Поднимите роль бота выше.`);
  }
  if (role.position <= minimumPosition) {
    await role.setPosition(minimumPosition + 1, { reason: "Grand Family Bot: соблюдение иерархии ролей" });
  }
  return role;
}

async function setMemberRank(member: GuildMember, family: Family, settings: Settings): Promise<void> {
  const managedRoleIds = relevantRankRoleIds(family, settings);
  await member.roles.remove(managedRoleIds, "Grand Family Bot: очистка старых рангов");
  await member.roles.add(rankRoleIds(family, settings), "Grand Family Bot: выдача ранга семьи");
}

async function createFamilyResources(
  guild: Guild,
  settings: Settings,
  application: Application,
  botMember: GuildMember,
): Promise<{ familyRole: Role; ldRole: Role; categoryId: string; textChannelId: string; voiceChannelId: string }> {
  if (!application.familyName || !application.colorHex || !application.rank || !application.nickname) {
    throw new Error("Заявка неполная: отсутствуют данные семьи.");
  }
  const existingFamily = guild.roles.cache.find(
    (role) => role.name === `Семья ${application.familyName}` && !role.managed,
  );
  if (existingFamily && !roleIsUsable(existingFamily, botMember)) {
    throw new Error(`Роль «Семья ${application.familyName}» уже существует, но бот не может ею управлять.`);
  }
  const familyBaseRole = await guild.roles.fetch(settings.familyRoleId);
  const leaderRole = await guild.roles.fetch(settings.leaderRoleId);
  if (!familyBaseRole || !leaderRole) throw new Error("Настроечная роль не найдена.");

  const familyRole = await ensureFamilyRole(
    guild,
    `Семья ${application.familyName}`,
    application.colorHex,
    familyBaseRole.position,
    botMember,
  );
  const ldRole = await ensureFamilyRole(
    guild,
    `LD ${application.familyName}`,
    application.colorHex,
    leaderRole.position,
    botMember,
  );

  const overwrites = [
    { id: guild.roles.everyone.id, type: OverwriteType.Role, deny: [PermissionFlagsBits.ViewChannel] },
    { id: familyRole.id, type: OverwriteType.Role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
    { id: ldRole.id, type: OverwriteType.Role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
    { id: settings.leaderRoleId, type: OverwriteType.Role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
    { id: settings.deputyLeaderRoleId, type: OverwriteType.Role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
    { id: settings.seniorRoleId, type: OverwriteType.Role, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
    { id: botMember.id, type: OverwriteType.Member, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
  ];
  const category = await guild.channels.create({
    name: `🏠・${application.familyName}`,
    type: ChannelType.GuildCategory,
    permissionOverwrites: overwrites,
    reason: "Grand Family Bot: создание категории семьи",
  });
  const textChannel = await guild.channels.create({
    name: "💬・общий",
    type: ChannelType.GuildText,
    parent: category.id,
    permissionOverwrites: overwrites,
    reason: "Grand Family Bot: создание текстового канала семьи",
  });
  const voiceChannel = await guild.channels.create({
    name: "🔊・общий",
    type: ChannelType.GuildVoice,
    parent: category.id,
    permissionOverwrites: overwrites,
    reason: "Grand Family Bot: создание голосового канала семьи",
  });
  return {
    familyRole,
    ldRole,
    categoryId: category.id,
    textChannelId: textChannel.id,
    voiceChannelId: voiceChannel.id,
  };
}

async function deleteChannelIfPresent(guild: Guild, id: string): Promise<void> {
  const channel = await guild.channels.fetch(id).catch(() => null);
  if (channel) await channel.delete("Grand Family Bot: удаление семьи");
}

async function deleteRoleIfPresent(guild: Guild, id: string): Promise<void> {
  const role = await guild.roles.fetch(id).catch(() => null);
  if (role && !role.managed) await role.delete("Grand Family Bot: удаление семьи");
}

async function sendApplicationReview(
  guild: Guild,
  settings: Settings,
  application: Application,
  db: BotDatabase,
): Promise<string> {
  const channel = await guild.channels.fetch(settings.applicationsChannelId);
  if (!channel?.isTextBased() || !("send" in channel)) throw new Error("Канал заявлений недоступен.");
  const evidence = application.evidenceUrls.map((url, index) => `[Доказательство ${index + 1}](${url})`).join("\n");
  const embed = new EmbedBuilder()
    .setColor(application.colorHex ? parseInt(application.colorHex.slice(1), 16) : 0x8b5cf6)
    .setTitle("Новое заявление на создание семьи")
    .addFields(
      { name: "Заявитель", value: `<@${application.userId}>`, inline: true },
      { name: "Никнейм", value: application.nickname ?? "—", inline: true },
      { name: "Название семьи", value: application.familyName ?? "—", inline: true },
      { name: "HEX-цвет", value: application.colorHex ?? "—", inline: true },
      { name: "Ранг", value: String(application.rank ?? "—"), inline: true },
      { name: "Доказательства", value: evidence || "—", inline: false },
    )
    .setFooter({ text: `Заявка #${application.id}` })
    .setTimestamp();
  const message = await channel.send({ embeds: [embed], components: reviewComponents("application", application.id) });
  db.updateApplicationEvidence(application.id, application.evidenceUrls, message.id);
  return message.id;
}

async function updateReviewMessage(
  guild: Guild,
  channelId: string,
  messageId: string | null,
  content: string,
): Promise<void> {
  if (!messageId) return;
  const channel = await guild.channels.fetch(channelId).catch(() => null);
  if (!channel?.isTextBased() || !("messages" in channel)) return;
  const message = await channel.messages.fetch(messageId).catch(() => null);
  if (message) await message.edit({ content, components: disabledComponents() });
}

async function notifyUser(guild: Guild, userId: string, content: string): Promise<void> {
  const user = await guild.client.users.fetch(userId).catch(() => null);
  if (user) await user.send(content).catch(() => undefined);
}

async function createPanel(interaction: ChatInputCommandInteraction, db: BotDatabase): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  if (!interaction.guild) return void (await interaction.editReply("Эта команда доступна только на сервере."));
  const settings = db.getSettings(interaction.guild.id);
  if (!settings) return void (await interaction.editReply("Сначала выполните `/setup` и завершите настройку."));
  const channel = await interaction.guild.channels.fetch(settings.panelChannelId);
  if (!channel?.isTextBased() || !("send" in channel)) {
    return void (await interaction.editReply("Канал панели недоступен. Проверьте настройки."));
  }
  if (settings.panelMessageId) {
    const oldMessage = await channel.messages.fetch(settings.panelMessageId).catch(() => null);
    if (oldMessage) {
      await oldMessage.edit({ embeds: [makePanelEmbed()], components: panelComponents() });
      return void (await interaction.editReply(`Панель обновлена в <#${channel.id}>.`));
    }
  }
  const message = await channel.send({ embeds: [makePanelEmbed()], components: panelComponents() });
  db.setPanelMessageId(interaction.guild.id, message.id);
  await interaction.editReply(`Панель создана в <#${channel.id}>.`);
}

async function handleSetup(interaction: ChatInputCommandInteraction, db: BotDatabase): Promise<void> {
  if (!interaction.guild) return void (await interaction.reply({ content: "Эта команда доступна только на сервере.", ephemeral: true }));
  const application = await interaction.client.application.fetch();
  const ownerId = application.owner?.id;
  if (!ownerId || ownerId !== interaction.user.id) {
    return void (await interaction.reply({ content: "Только владелец Discord Application может выполнять настройку.", ephemeral: true }));
  }
  setupDrafts.delete(setupKey(interaction.guild.id, interaction.user.id));
  await interaction.showModal(setupStageOneModal());
}

async function handleStageOne(interaction: import("discord.js").ModalSubmitInteraction, db: BotDatabase): Promise<void> {
  if (!interaction.guild) return void (await interaction.reply({ content: "Эта форма доступна только на сервере.", ephemeral: true }));
  const draft: SetupStageOneDraft = {
    guildId: interaction.guild.id,
    panelChannelId: interaction.fields.getTextInputValue("panel_channel_id").trim(),
    applicationsChannelId: interaction.fields.getTextInputValue("applications_channel_id").trim(),
    mainCuratorRoleId: interaction.fields.getTextInputValue("main_curator_role_id").trim(),
    deputyCuratorRoleId: interaction.fields.getTextInputValue("deputy_curator_role_id").trim(),
    leaderRoleId: interaction.fields.getTextInputValue("leader_role_id").trim(),
  };
  try {
    for (const id of [draft.panelChannelId, draft.applicationsChannelId, draft.mainCuratorRoleId, draft.deputyCuratorRoleId, draft.leaderRoleId]) {
      if (!DISCORD_ID_PATTERN.test(id)) throw new Error(`Значение «${id}» не похоже на Discord ID.`);
    }
    await validateSetupIds(interaction.guild, {
      ...draft,
      deputyLeaderRoleId: draft.leaderRoleId,
      seniorRoleId: draft.leaderRoleId,
      familyRoleId: draft.leaderRoleId,
    });
    setupDrafts.set(setupKey(interaction.guild.id, interaction.user.id), { expiresAt: Date.now() + SETUP_TTL_MS, draft });
    await interaction.reply({
      content: "Этап 1 проверен. Нажмите кнопку ниже, чтобы открыть этап 2.",
      components: setupContinueComponents(),
      ephemeral: true,
    });
  } catch (error) {
    await interaction.reply({ content: `Не удалось проверить этап 1: ${errorText(error)}`, ephemeral: true });
  }
}

async function handleStageTwo(interaction: import("discord.js").ModalSubmitInteraction, db: BotDatabase): Promise<void> {
  if (!interaction.guild) return void (await interaction.reply({ content: "Эта форма доступна только на сервере.", ephemeral: true }));
  const key = setupKey(interaction.guild.id, interaction.user.id);
  const saved = setupDrafts.get(key);
  if (!saved || saved.expiresAt < Date.now()) {
    setupDrafts.delete(key);
    return void (await interaction.reply({ content: "Сессия настройки истекла. Запустите `/setup` заново.", ephemeral: true }));
  }
  const settings: SetupDraft = {
    ...saved.draft,
    deputyLeaderRoleId: interaction.fields.getTextInputValue("deputy_leader_role_id").trim(),
    seniorRoleId: interaction.fields.getTextInputValue("senior_role_id").trim(),
    familyRoleId: interaction.fields.getTextInputValue("family_role_id").trim(),
  };
  try {
    for (const id of [settings.deputyLeaderRoleId, settings.seniorRoleId, settings.familyRoleId]) {
      if (!DISCORD_ID_PATTERN.test(id)) throw new Error(`Значение «${id}» не похоже на Discord ID.`);
    }
    await validateSetupIds(interaction.guild, settings);
    db.saveSettings(settings);
    setupDrafts.delete(key);
    await interaction.reply({
      content:
        "Настройка завершена. Владелец ввёл 8 ID:\n" +
        "1) канал панели, 2) канал заявлений, 3) роль главного куратора, 4) роль заместителя куратора,\n" +
        "5) роль лидера, 6) роль заместителя, 7) роль старшего состава, 8) базовая роль семьи.\n\n" +
        "Теперь выполните `/panel`.",
      ephemeral: true,
    });
  } catch (error) {
    await interaction.reply({ content: `Не удалось сохранить настройку: ${errorText(error)}`, ephemeral: true });
  }
}

async function startApplication(interaction: import("discord.js").ModalSubmitInteraction, db: BotDatabase): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  if (!interaction.guild) return void (await interaction.editReply("Эта форма доступна только на сервере."));
  const settings = db.getSettings(interaction.guild.id);
  if (!settings) return void (await interaction.editReply("Сначала завершите настройку бота через `/setup`."));
  const nickname = interaction.fields.getTextInputValue("nickname").trim();
  const familyName = interaction.fields.getTextInputValue("family_name").trim();
  const colorHex = interaction.fields.getTextInputValue("color_hex").trim();
  const rankText = interaction.fields.getTextInputValue("rank").trim();
  const rank = Number(rankText);
  if (!nickname || !familyName) return void (await interaction.editReply("Никнейм и название семьи обязательны."));
  if (!HEX_PATTERN.test(colorHex)) return void (await interaction.editReply("HEX-цвет должен быть в формате `#RRGGBB`."));
  if (!Number.isInteger(rank) || rank < 1 || rank > 10) return void (await interaction.editReply("Ранг должен быть целым числом от 1 до 10."));
  if (db.getFamilyByName(interaction.guild.id, familyName)) return void (await interaction.editReply("Семья с таким названием уже существует."));
  const tempChannel = await interaction.guild.channels.create({
    name: `заявка-${interaction.user.username}`.slice(0, 90),
    type: ChannelType.GuildText,
    permissionOverwrites: [
      { id: interaction.guild.roles.everyone.id, type: OverwriteType.Role, deny: [PermissionFlagsBits.ViewChannel] },
      { id: interaction.user.id, type: OverwriteType.Member, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles, PermissionFlagsBits.ReadMessageHistory] },
      { id: interaction.client.user.id, type: OverwriteType.Member, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] },
    ],
    reason: "Grand Family Bot: временный канал заявления",
  });
  const applicationId = db.createApplication({
    guildId: interaction.guild.id,
    type: "create",
    userId: interaction.user.id,
    nickname,
    familyName,
    colorHex,
    rank,
    tempChannelId: tempChannel.id,
  });
  await tempChannel.send({
    content:
      `<@${interaction.user.id}>, отправьте **ровно 3 изображения** одним или несколькими сообщениями.\n` +
      "Принимаются только изображения. После третьего файл будет отправлен кураторам автоматически.",
  });
  await interaction.editReply(`Канал для доказательств создан: <#${tempChannel.id}>.`);
}

async function handleEvidence(message: import("discord.js").Message, db: BotDatabase): Promise<void> {
  if (message.author.bot || !message.guild) return;
  const pending = findApplicationByTempChannel(db, message.channel.id);
  if (!pending || pending.status !== "collecting_evidence" || pending.userId !== message.author.id) return;
  const images = [...message.attachments.values()].filter((attachment) => {
    return Boolean(attachment.contentType?.startsWith("image/")) || /\.(png|jpe?g|gif|webp|bmp)$/i.test(attachment.name ?? "");
  });
  if (images.length !== message.attachments.size || images.length === 0) {
    await message.reply("Принимаются только изображения. Отправьте недостающие файлы ещё раз.").catch(() => undefined);
    return;
  }
  if (images.length > 3) {
    await message.reply("Нужно отправить ровно 3 изображения. В этом сообщении слишком много файлов.").catch(() => undefined);
    return;
  }
  const existingCount = pending.evidenceUrls.length;
  const urls = [...pending.evidenceUrls, ...images.map((attachment) => attachment.url)];
  if (urls.length > 3) {
    await message.reply(`Уже принято ${existingCount}. Отправьте только ${3 - existingCount} изображени${3 - existingCount === 1 ? "е" : "я"}.`).catch(() => undefined);
    return;
  }
  if (urls.length < 3) {
    const remaining = 3 - urls.length;
    await message.reply(`Принято ${urls.length}/3. Осталось отправить: ${remaining}.`).catch(() => undefined);
    updateEvidenceOnly(db, pending.id, urls);
    return;
  }
  const appWithEvidence = { ...pending, evidenceUrls: urls };
  try {
    const settings = db.getSettings(message.guild.id);
    if (!settings) throw new Error("Настройка бота не найдена.");
    await sendApplicationReview(message.guild, settings, appWithEvidence, db);
    if (message.channel.isTextBased() && "send" in message.channel) {
      await message.channel.send("Все 3 доказательства приняты. Канал будет закрыт.").catch(() => undefined);
    }
    await message.channel.delete("Grand Family Bot: доказательства собраны");
  } catch (error) {
    logger.error({ err: error, applicationId: pending.id }, "Unable to send application review");
    await message.reply(`Не удалось отправить заявление кураторам: ${errorText(error)}`).catch(() => undefined);
  }
}

function findApplicationByTempChannel(db: BotDatabase, channelId: string): Application | null {
  return db.getApplicationByTempChannel(channelId);
}

function updateEvidenceOnly(db: BotDatabase, id: number, urls: string[]): void {
  db.updateEvidenceUrls(id, urls);
}

async function approveApplication(
  interaction: ButtonInteraction,
  id: number,
  db: BotDatabase,
): Promise<void> {
  await interaction.deferUpdate();
  const guild = interaction.guild;
  if (!guild) return void (await interaction.followUp({ content: "Эта заявка доступна только на сервере.", ephemeral: true }));
  const settings = db.getSettings(guild.id);
  if (!settings) return void (await interaction.followUp({ content: "Настройка бота не найдена.", ephemeral: true }));
  const member = await guild.members.fetch(interaction.user.id);
  if (!isCurator(member, settings)) return void (await interaction.followUp({ content: "Только главный куратор или его заместитель может рассматривать заявки.", ephemeral: true }));
  const application = db.getApplication(id);
  if (!application || application.status !== "pending") return void (await interaction.followUp({ content: "Эта заявка уже рассмотрена или не найдена.", ephemeral: true }));
  try {
    const bot = await fetchBotMember(guild);
    const resources = await createFamilyResources(guild, settings, application, bot);
    const family: Family = {
      id: 0,
      guildId: guild.id,
      name: application.familyName!,
      ownerId: application.userId,
      nickname: application.nickname!,
      rank: application.rank!,
      familyRoleId: resources.familyRole.id,
      ldRoleId: resources.ldRole.id,
      categoryId: resources.categoryId,
      textChannelId: resources.textChannelId,
      voiceChannelId: resources.voiceChannelId,
      status: "active",
    };
    const familyId = db.createFamily(family);
    const createdFamily = { ...family, id: familyId };
    const owner = await guild.members.fetch(application.userId);
    await setMemberRank(owner, createdFamily, settings);
    db.setApplicationStatus(id, "approved", interaction.user.id);
    await updateReviewMessage(guild, settings.applicationsChannelId, application.reviewMessageId, `✅ Заявка #${id} одобрена куратором <@${interaction.user.id}>.`);
    await notifyUser(guild, application.userId, `Ваша семья **${application.familyName}** одобрена. Роли и каналы созданы.`);
    await interaction.followUp({ content: `Заявка #${id} одобрена. Семья создана.`, ephemeral: true });
  } catch (error) {
    logger.error({ err: error, applicationId: id }, "Unable to approve family application");
    await interaction.followUp({ content: `Не удалось одобрить заявку: ${errorText(error)}`, ephemeral: true });
  }
}

async function rejectApplication(interaction: import("discord.js").ModalSubmitInteraction, id: number, db: BotDatabase): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild = interaction.guild;
  if (!guild) return void (await interaction.editReply("Эта заявка доступна только на сервере."));
  const settings = db.getSettings(guild.id);
  if (!settings) return void (await interaction.editReply("Настройка бота не найдена."));
  const member = await guild.members.fetch(interaction.user.id);
  if (!isCurator(member, settings)) return void (await interaction.editReply("Недостаточно прав куратора."));
  const application = db.getApplication(id);
  if (!application || application.status !== "pending") return void (await interaction.editReply("Эта заявка уже рассмотрена."));
  const reason = interaction.fields.getTextInputValue("reason").trim();
  db.setApplicationStatus(id, "rejected", interaction.user.id, reason);
  await updateReviewMessage(guild, settings.applicationsChannelId, application.reviewMessageId, `❌ Заявка #${id} отклонена куратором <@${interaction.user.id}>.\nПричина: ${reason}`);
  await notifyUser(guild, application.userId, `Заявка на семью **${application.familyName ?? "без названия"}** отклонена.\nПричина: ${reason}`);
  await interaction.editReply("Заявка отклонена, причина сохранена.");
}

async function createTransfer(interaction: import("discord.js").ModalSubmitInteraction, db: BotDatabase): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild = interaction.guild;
  if (!guild) return void (await interaction.editReply("Эта форма доступна только на сервере."));
  const settings = db.getSettings(guild.id);
  if (!settings) return void (await interaction.editReply("Сначала настройте бота."));
  const family = db.getFamilyByOwner(guild.id, interaction.user.id);
  if (!family) return void (await interaction.editReply("Вы не являетесь владельцем активной семьи."));
  const targetId = cleanId(interaction.fields.getTextInputValue("target_user_id"));
  if (!DISCORD_ID_PATTERN.test(targetId)) return void (await interaction.editReply("Укажите корректный Discord ID или mention."));
  const target = await guild.members.fetch(targetId).catch(() => null);
  if (!target) return void (await interaction.editReply("Пользователь с таким ID не найден на сервере."));
  if (target.user.bot) return void (await interaction.editReply("Нельзя передать семью боту."));
  if (target.id === interaction.user.id) return void (await interaction.editReply("Новый владелец должен быть другим участником."));
  const transferId = db.createTransfer({ guildId: guild.id, familyId: family.id, fromUserId: interaction.user.id, targetUserId: target.id });
  const channel = await guild.channels.fetch(settings.applicationsChannelId);
  if (!channel?.isTextBased() || !("send" in channel)) return void (await interaction.editReply("Канал заявлений недоступен."));
  const message = await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(0xf59e0b)
        .setTitle("Заявка на передачу семьи")
        .setDescription(`Семья **${family.name}**\nОт: <@${interaction.user.id}>\nКому: <@${target.id}>`)
        .setFooter({ text: `Передача #${transferId}` })
        .setTimestamp(),
    ],
    components: reviewComponents("transfer", transferId),
  });
  db.setTransferReviewMessage(transferId, message.id);
  await interaction.editReply(`Заявка на передачу отправлена кураторам. Номер: #${transferId}.`);
}

async function approveTransfer(interaction: ButtonInteraction, id: number, db: BotDatabase): Promise<void> {
  await interaction.deferUpdate();
  const guild = interaction.guild;
  if (!guild) return;
  const settings = db.getSettings(guild.id);
  if (!settings) return void (await interaction.followUp({ content: "Настройка не найдена.", ephemeral: true }));
  const reviewer = await guild.members.fetch(interaction.user.id);
  if (!isCurator(reviewer, settings)) return void (await interaction.followUp({ content: "Недостаточно прав куратора.", ephemeral: true }));
  const transfer = db.getTransfer(id);
  if (!transfer || transfer.status !== "pending") return void (await interaction.followUp({ content: "Эта передача уже рассмотрена.", ephemeral: true }));
  const family = db.getFamily(transfer.familyId);
  if (!family) return void (await interaction.followUp({ content: "Семья уже удалена.", ephemeral: true }));
  try {
    const oldOwner = await guild.members.fetch(transfer.fromUserId).catch(() => null);
    const newOwner = await guild.members.fetch(transfer.targetUserId);
    if (oldOwner) await oldOwner.roles.remove(relevantRankRoleIds(family, settings), "Grand Family Bot: передача семьи");
    await setMemberRank(newOwner, family, settings);
    db.updateFamilyOwner(family.id, newOwner.id);
    db.setTransferStatus(id, "approved", interaction.user.id);
    await updateReviewMessage(guild, settings.applicationsChannelId, transfer.reviewMessageId, `✅ Передача #${id} одобрена куратором <@${interaction.user.id}>.`);
    await notifyUser(guild, newOwner.id, `Вы стали владельцем семьи **${family.name}**.`);
    await interaction.followUp({ content: `Передача #${id} одобрена.`, ephemeral: true });
  } catch (error) {
    logger.error({ err: error, transferId: id }, "Unable to approve family transfer");
    await interaction.followUp({ content: `Не удалось одобрить передачу: ${errorText(error)}`, ephemeral: true });
  }
}

async function rejectTransfer(interaction: import("discord.js").ModalSubmitInteraction, id: number, db: BotDatabase): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild = interaction.guild;
  if (!guild) return;
  const settings = db.getSettings(guild.id);
  if (!settings) return void (await interaction.editReply("Настройка не найдена."));
  const reviewer = await guild.members.fetch(interaction.user.id);
  if (!isCurator(reviewer, settings)) return void (await interaction.editReply("Недостаточно прав куратора."));
  const transfer = db.getTransfer(id);
  if (!transfer || transfer.status !== "pending") return void (await interaction.editReply("Эта передача уже рассмотрена."));
  const reason = interaction.fields.getTextInputValue("reason").trim();
  db.setTransferStatus(id, "rejected", interaction.user.id, reason);
  await updateReviewMessage(guild, settings.applicationsChannelId, transfer.reviewMessageId, `❌ Передача #${id} отклонена.\nПричина: ${reason}`);
  await notifyUser(guild, transfer.fromUserId, `Передача семьи отклонена.\nПричина: ${reason}`);
  await interaction.editReply("Передача отклонена.");
}

async function createDeleteRequest(interaction: import("discord.js").ModalSubmitInteraction, db: BotDatabase): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild = interaction.guild;
  if (!guild) return void (await interaction.editReply("Эта форма доступна только на сервере."));
  const settings = db.getSettings(guild.id);
  if (!settings) return void (await interaction.editReply("Сначала настройте бота."));
  const family = db.getFamilyByOwner(guild.id, interaction.user.id);
  if (!family) return void (await interaction.editReply("Вы не являетесь владельцем активной семьи."));
  const reason = interaction.fields.getTextInputValue("reason").trim();
  const applicationId = db.createApplication({
    guildId: guild.id,
    type: "delete",
    userId: interaction.user.id,
    familyId: family.id,
    reason,
  });
  const channel = await guild.channels.fetch(settings.applicationsChannelId);
  if (!channel?.isTextBased() || !("send" in channel)) return void (await interaction.editReply("Канал заявлений недоступен."));
  const message = await channel.send({
    embeds: [
      new EmbedBuilder()
        .setColor(0xef4444)
        .setTitle("Заявка на удаление семьи")
        .setDescription(`Семья **${family.name}**\nВладелец: <@${interaction.user.id}>\nПричина: ${reason}`)
        .setFooter({ text: `Удаление #${applicationId}` })
        .setTimestamp(),
    ],
    components: reviewComponents("application", applicationId),
  });
  db.setApplicationReviewMessage(applicationId, message.id);
  await interaction.editReply(`Заявка на удаление отправлена кураторам. Номер: #${applicationId}.`);
}

async function approveDelete(interaction: ButtonInteraction, id: number, db: BotDatabase): Promise<void> {
  await interaction.deferUpdate();
  const guild = interaction.guild;
  if (!guild) return;
  const settings = db.getSettings(guild.id);
  if (!settings) return void (await interaction.followUp({ content: "Настройка не найдена.", ephemeral: true }));
  const reviewer = await guild.members.fetch(interaction.user.id);
  if (!isCurator(reviewer, settings)) return void (await interaction.followUp({ content: "Недостаточно прав куратора.", ephemeral: true }));
  const application = db.getApplication(id);
  if (!application || application.status !== "pending" || application.type !== "delete" || !application.familyId) {
    return void (await interaction.followUp({ content: "Заявка уже рассмотрена или не найдена.", ephemeral: true }));
  }
  const family = db.getFamily(application.familyId);
  if (!family) return void (await interaction.followUp({ content: "Семья уже удалена.", ephemeral: true }));
  try {
    await deleteChannelIfPresent(guild, family.textChannelId);
    await deleteChannelIfPresent(guild, family.voiceChannelId);
    await deleteChannelIfPresent(guild, family.categoryId);
    await deleteRoleIfPresent(guild, family.ldRoleId);
    await deleteRoleIfPresent(guild, family.familyRoleId);
    db.deleteFamily(family.id);
    db.setApplicationStatus(id, "approved", interaction.user.id);
    await updateReviewMessage(guild, settings.applicationsChannelId, application.reviewMessageId, `✅ Удаление #${id} одобрено. Семья **${family.name}** полностью удалена.`);
    await notifyUser(guild, application.userId, `Семья **${family.name}** полностью удалена после одобрения куратора.`);
    await interaction.followUp({ content: `Семья «${family.name}» полностью удалена.`, ephemeral: true });
  } catch (error) {
    logger.error({ err: error, applicationId: id, familyId: family.id }, "Unable to delete family");
    await interaction.followUp({ content: `Не удалось полностью удалить семью: ${errorText(error)}`, ephemeral: true });
  }
}

async function routeInteraction(interaction: Interaction, db: BotDatabase): Promise<void> {
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === "setup" || interaction.commandName === "настройка") return handleSetup(interaction, db);
    if (interaction.commandName === "panel" || interaction.commandName === "панель") return createPanel(interaction, db);
  }
  if (interaction.isButton()) {
    if (interaction.customId === "setup:continue") {
      return void (await interaction.showModal(setupStageTwoModal()));
    }
    if (interaction.customId === "panel:apply") return void (await interaction.showModal(applicationModal()));
    if (interaction.customId === "panel:delete") return void (await interaction.showModal(deleteModal()));
    if (interaction.customId === "panel:transfer") return void (await interaction.showModal(transferModal()));
    const [scope, action, kind, rawId] = interaction.customId.split(":");
    if (scope !== "review" || !rawId) return;
    const id = Number(rawId);
    if (!Number.isInteger(id)) return;
    if (action === "approve" && kind === "application") {
      const app = db.getApplication(id);
      if (app?.type === "delete") return approveDelete(interaction, id, db);
      return approveApplication(interaction, id, db);
    }
    if (action === "approve" && kind === "transfer") return approveTransfer(interaction, id, db);
    if (action === "reject") return void (await interaction.showModal(rejectModal(kind === "transfer" ? "transfer" : "application", id)));
  }
  if (interaction.isModalSubmit()) {
    if (interaction.customId === "setup:stage1") return handleStageOne(interaction, db);
    if (interaction.customId === "setup:stage2") return handleStageTwo(interaction, db);
    if (interaction.customId === "application:create") return startApplication(interaction, db);
    if (interaction.customId === "family:transfer") return createTransfer(interaction, db);
    if (interaction.customId === "family:delete") return createDeleteRequest(interaction, db);
    const match = /^review:reject:(application|transfer):(\d+)$/.exec(interaction.customId);
    if (match) {
      const id = Number(match[2]);
      if (match[1] === "transfer") return rejectTransfer(interaction, id, db);
      return rejectApplication(interaction, id, db);
    }
  }
}

export function createDiscordBot(db: BotDatabase): Client {
  const token = process.env["DISCORD_BOT_TOKEN"];
  if (!token) throw new Error("DISCORD_BOT_TOKEN is required.");
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
  });
  client.once(Events.ClientReady, async (readyClient) => {
    logger.info({ user: readyClient.user.tag }, "Discord client ready");
    const commands = [
      {
        name: "setup",
        description: "Настроить Grand Family Bot",
        name_localizations: { ru: "настройка" },
      },
      {
        name: "panel",
        description: "Создать или обновить панель",
        name_localizations: { ru: "панель" },
      },
    ];
    try {
      const rest = new REST({ version: "10" }).setToken(token);
      await rest.put(Routes.applicationCommands(readyClient.user.id), { body: commands });
      logger.info({ commands: ["setup", "panel"], russianLocalizations: true }, "Slash commands registered");
    } catch (error) {
      logger.error({ err: error }, "Unable to register slash commands");
    }
  });
  client.on(Events.InteractionCreate, (interaction) => {
    routeInteraction(interaction, db).catch((error) => {
      logger.error({ err: error, interactionId: interaction.id }, "Unhandled interaction error");
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        interaction.reply({ content: "Произошла внутренняя ошибка. Попробуйте ещё раз.", ephemeral: true }).catch(() => undefined);
      }
    });
  });
  client.on(Events.MessageCreate, (message) => {
    handleEvidence(message, db).catch((error) => logger.error({ err: error }, "Unhandled evidence collection error"));
  });
  client.on("error", (error) => logger.error({ err: error }, "Discord client error"));
  void client.login(token).catch((error) => {
    logger.error({ err: error }, "Discord Gateway login failed");
  });
  return client;
}